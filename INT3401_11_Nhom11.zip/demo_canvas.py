import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import numpy as np
import torch
from PIL import Image, ImageFilter
import gradio as gr
import models
import backend
import train

# Đổi sang True nếu muốn dùng Q5 (DigitConvolutionalModel)
USE_CNN = False

print("1/3: Đang khởi tạo và huấn luyện mô hình...")
if USE_CNN and hasattr(models, "DigitConvolutionalModel"):
    model = models.DigitConvolutionalModel()
    dataset = backend.DigitClassificationDataset(model)
    train_fn = getattr(train, "train_digitconvolutional", train.train_digitclassifier)
    train_fn(model, dataset)
else:
    model = models.DigitClassificationModel()
    dataset = backend.DigitClassificationDataset(model)
    train.train_digitclassifier(model, dataset)

model.eval()

# Tự động kiểm tra xem dataset của project có bị xoay chiều (Transpose) không
with torch.no_grad():
    sample_x = torch.tensor(dataset.dev_images[:200], dtype=torch.float32)
    sample_y = dataset.dev_labels[:200]
    if sample_y.ndim > 1:
        sample_y = np.argmax(sample_y, axis=1)

    out_normal = model.run(sample_x) if hasattr(model, "run") else model(sample_x)
    acc_normal = (torch.argmax(out_normal, dim=1).numpy() == sample_y).mean()

    sample_x_T = torch.tensor(
        dataset.dev_images[:200].reshape(-1, 28, 28).transpose(0, 2, 1).reshape(-1, 784),
        dtype=torch.float32
    )
    out_T = model.run(sample_x_T) if hasattr(model, "run") else model(sample_x_T)
    acc_T = (torch.argmax(out_T, dim=1).numpy() == sample_y).mean()

    NEED_TRANSPOSE = acc_T > acc_normal
    print(f"3/3: Huấn luyện xong! Độ chính xác kiểm tra: {max(acc_normal, acc_T)*100:.1f}%")


def trich_xuat_net_ve(image):
    """Lấy chính xác nét mực từ Gradio Sketchpad (hỗ trợ cả RGBA trong suốt và RGB)."""
    if image is None:
        return None

    img = image.get("composite") if isinstance(image, dict) else image
    if img is None:
        return None

    img = np.array(img)
    if img.ndim == 2:
        border_median = np.median(np.concatenate([img[0, :], img[-1, :], img[:, 0], img[:, -1]]))
        ink = (255.0 - img) if border_median > 127 else img.astype(np.float32)
    elif img.shape[2] == 4:
        alpha = img[:, :, 3].astype(np.float32)
        rgb_gray = img[:, :, :3].mean(axis=2)
        if np.median([alpha[0, 0], alpha[0, -1], alpha[-1, 0], alpha[-1, -1]]) < 10:
            ink = alpha
        else:
            white_bg_gray = rgb_gray * (alpha / 255.0) + 255.0 * (1.0 - alpha / 255.0)
            ink = 255.0 - white_bg_gray
    else:
        rgb_gray = img[:, :, :3].mean(axis=2)
        border_median = np.median(np.concatenate([rgb_gray[0, :], rgb_gray[-1, :], rgb_gray[:, 0], rgb_gray[:, -1]]))
        ink = (255.0 - rgb_gray) if border_median > 127 else rgb_gray

    return np.clip(ink, 0, 255).astype(np.uint8)


def chuan_hoa_mnist_28x28(ink):
    """Cắt sát nét vẽ, làm dày nét bút giống MNIST, đưa vào khung 20x20 và căn trọng tâm 28x28."""
    if ink is None or ink.max() < 20:
        return None

    ys, xs = np.where(ink > 25)
    if len(xs) == 0 or len(ys) == 0:
        return None

    cropped = ink[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = cropped.shape

    size = max(h, w)
    pil_crop = Image.fromarray(cropped)
    if size > 60:
        pil_crop = pil_crop.filter(ImageFilter.MaxFilter(5))
    if size > 150:
        pil_crop = pil_crop.filter(ImageFilter.MaxFilter(5))

    cropped = np.array(pil_crop)

    if h > w:
        new_h = 20
        new_w = max(1, int(round(w * (20.0 / h))))
    else:
        new_w = 20
        new_h = max(1, int(round(h * (20.0 / w))))

    pil_20 = Image.fromarray(cropped).resize((new_w, new_h), Image.Resampling.BILINEAR)
    pil_20 = pil_20.filter(ImageFilter.GaussianBlur(radius=0.45))
    arr_20 = np.array(pil_20, dtype=np.float32)

    if arr_20.max() > 0:
        arr_20 = np.clip((arr_20 / arr_20.max()) * 255.0, 0, 255)

    canvas = np.zeros((28, 28), dtype=np.float32)
    y0 = (28 - new_h) // 2
    x0 = (28 - new_w) // 2
    canvas[y0:y0 + new_h, x0:x0 + new_w] = arr_20

    mass = canvas.sum()
    if mass > 0:
        gy, gx = np.indices((28, 28))
        cy = (gy * canvas).sum() / mass
        cx = (gx * canvas).sum() / mass
        dy = int(np.clip(round(13.5 - cy), -4, 4))
        dx = int(np.clip(round(13.5 - cx), -4, 4))

        shifted = np.zeros_like(canvas)
        src_y0, src_y1 = max(0, -dy), min(28, 28 - dy)
        src_x0, src_x1 = max(0, -dx), min(28, 28 - dx)
        dst_y0, dst_y1 = max(0, dy), min(28, 28 + dy)
        dst_x0, dst_x1 = max(0, dx), min(28, 28 + dx)
        shifted[dst_y0:dst_y1, dst_x0:dst_x1] = canvas[src_y0:src_y1, src_x0:src_x1]
        canvas = shifted

    if NEED_TRANSPOSE:
        canvas = canvas.T

    return canvas


def ai_du_doan(image):
    ink = trich_xuat_net_ve(image)
    canvas_28 = chuan_hoa_mnist_28x28(ink)

    if canvas_28 is None:
        return "Hãy vẽ một chữ số vào khung bên trái...", {}, np.zeros((28, 28), dtype=np.uint8)

    img_norm = (canvas_28 / 255.0).astype(np.float32)
    input_tensor = torch.tensor(img_norm.reshape(1, 784), dtype=torch.float32)

    with torch.no_grad():
        logits = model.run(input_tensor) if hasattr(model, "run") else model(input_tensor)
        probs = torch.softmax(logits, dim=1)[0].numpy()

    pred = int(np.argmax(probs))
    conf = float(probs[pred]) * 100.0
    bang_xac_suat = {f"Số {i}": float(probs[i]) for i in range(10)}

    return (
        f"AI đoán đây là số: {pred} (Độ tự tin: {conf:.1f}%)",
        bang_xac_suat,
        canvas_28.astype(np.uint8)
    )


with gr.Blocks(title="Demo Nhận diện chữ số viết tay (Computer Vision)") as giao_dien:
    gr.Markdown("## Demo Nhận diện chữ số viết tay (Q3 & Q5 - Computer Vision)\nVẽ một chữ số từ **0 đến 9** bằng chuột. Hệ thống tự động trích xuất kênh mực, làm dày nét và căn trọng tâm chuẩn MNIST.")
    with gr.Row():
        with gr.Column(scale=1):
            khung_ve = gr.Sketchpad(type="numpy", label="Khu vực vẽ (Dùng chuột)")
        with gr.Column(scale=1):
            ket_qua_text = gr.Textbox(label="Kết quả nhận diện")
            xac_suat_top = gr.Label(num_top_classes=3, label="Top 3 chữ số giống nhất")
            anh_28x28 = gr.Image(label="Ảnh 28x28 thực tế đưa vào mạng nơ-ron", image_mode="L", width=180, height=180)

    khung_ve.change(
        fn=ai_du_doan,
        inputs=khung_ve,
        outputs=[ket_qua_text, xac_suat_top, anh_28x28]
    )

giao_dien.launch(inbrowser=True)