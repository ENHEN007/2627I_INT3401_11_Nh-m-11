from torch import no_grad
from torch.utils.data import DataLoader

"""
Functions you should use.
Please avoid importing any other functions or modules.
Your code will not pass if the gradescope autograder detects any changed imports
"""
from torch import optim, tensor
from losses import regression_loss, digitclassifier_loss, languageid_loss, digitconvolution_Loss
from torch import movedim

"""
##################
### QUESTION 1 ###
##################
"""

def train_perceptron(model, dataset):
    """
    Train the perceptron until convergence.
    """
    with no_grad():
        # Perceptron cập nhật từng điểm một nên dùng batch_size = 1
        dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
        
        while True:
            errors = 0
            for batch in dataloader:
                x = batch['x']
                label = batch['label']
                
                # Trích xuất giá trị nhãn thực (item) để so sánh với dự đoán
                if model.get_prediction(x) != label.item():
                    model.w += label * x  # Luật cập nhật: w = w + y*x
                    errors += 1
            
            # Hội tụ khi duyệt qua toàn bộ dữ liệu mà không đoán sai lỗi nào
            if errors == 0:
                break


def train_regression(model, dataset):
    """
    Trains the Regression model.
    """
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    dataloader = DataLoader(dataset, batch_size=200, shuffle=True)
    
    # Dùng vòng lặp for giới hạn số epoch thay vì while True để tránh infinite loop
    for epoch in range(3000): 
        total_loss = 0
        for batch in dataloader:
            x = batch['x']
            label = batch['label']
            
            optimizer.zero_grad()
            predictions = model(x)
            loss = regression_loss(predictions, label)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
        # Ép ngưỡng ngắt vòng lặp xuống thấp hơn (0.015) để chắc chắn đỗ autograder
        if (total_loss / len(dataloader)) < 0.015:
            break

def train_digitclassifier(model, dataset):
    """
    Trains the Digit Classification model.
    """
    model.train()
    # Phân loại ảnh MNIST, dùng learning rate nhỏ hơn để tránh trượt qua đáy loss
    optimizer = optim.Adam(model.parameters(), lr=0.005)
    dataloader = DataLoader(dataset, batch_size=128, shuffle=True)
    
    # 10 epochs là đủ để MLP đạt >97% accuracy trên tập MNIST
    for epoch in range(10):
        for batch in dataloader:
            x = batch['x']
            label = batch['label']
            
            optimizer.zero_grad()
            out = model(x)
            loss = digitclassifier_loss(out, label)
            loss.backward()
            optimizer.step()


def train_languageid(model, dataset):
    """
    Trains the Language ID model.
    """
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=0.005)
    dataloader = DataLoader(dataset, batch_size=128, shuffle=True)
    
    # Huấn luyện RNN trong khoảng 15 epochs để đạt >81% accuracy
    for epoch in range(15):
        for batch in dataloader:
            xs = batch['x']
            label = batch['label']
            
            # Đảo chiều batch và chiều dài chuỗi từ (batch, seq, features) -> (seq, batch, features)
            xs = movedim(xs, 0, 1)
            
            optimizer.zero_grad()
            out = model(xs)
            loss = languageid_loss(out, label)
            loss.backward()
            optimizer.step()


def Train_DigitConvolution(model, dataset):
    """
    Trains the Convolutional model.
    """
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=0.005)
    dataloader = DataLoader(dataset, batch_size=128, shuffle=True)
    
    # Mạng CNN có trích xuất đặc trưng không gian tốt, chỉ cần 5 epochs là đủ hội tụ
    for epoch in range(5):
        for batch in dataloader:
            x = batch['x']
            label = batch['label']
            
            optimizer.zero_grad()
            out = model(x)
            loss = digitconvolution_Loss(out, label)
            loss.backward()
            optimizer.step()