1. Question 1 (5/5 điểm): Perceptron (Phân loại nhị phân cơ bản)
Mục tiêu: Xây dựng thuật toán phân loại tuyến tính sơ khai nhất, dự đoán một điểm dữ liệu thuộc lớp 1 hay -1.
models.py: Khởi tạo ma trận trọng số w bằng 0. Hàm forward tính tích vô hướng (dot product) giữa đầu vào x và w.
train.py: Không dùng hàm loss hay optimizer tự động của PyTorch. Thuật toán tự duyệt qua từng điểm dữ liệu (batch size = 1), nếu đoán sai thì cập nhật thủ công theo công thức: ww+yx.
2. Question 2 (5/5 điểm): Non-linear Regression (Hồi quy phi tuyến)
Mục tiêu: Xấp xỉ một đường cong (hàm sin) thay vì đường thẳng.
models.py: Xây dựng mạng Multi-Layer Perceptron (MLP) gồm 3 lớp Linear (1  128  64  1) xen kẽ với hàm kích hoạt phi tuyến ReLU.
losses.py: Sử dụng sai số bình phương trung bình (MSE Loss) để đo khoảng cách chênh lệch giữa đường cong dự đoán và thực tế.
train.py: Dùng thuật toán tối ưu Adam, huấn luyện theo từng batch lớn. Vòng lặp dừng lại khi trung bình sai số (Loss) giảm xuống dưới mức 0.015.
3. Question 3 (5/5 điểm): Digit Classification (Phân loại ảnh chữ số MNIST)
Mục tiêu: Nhận diện ảnh chữ số viết tay từ 0 đến 9 (đã được duỗi thẳng từ lưới 28x28 thành vector 784 chiều).
models.py: Xây dựng mạng MLP lớn hơn (784  256  128  10) để phân loại 10 nhãn.
losses.py: Đổi sang dùng Cross-Entropy Loss (hàm mất mát chuyên dụng cho bài toán phân loại nhiều lớp).
train.py: Huấn luyện bằng optimizer Adam trong 10 epoch để đạt độ chính xác (accuracy) $>97\%$.
4. Question 4 (5/5 điểm): Language Identification (Nhận diện ngôn ngữ)
Mục tiêu: Xác định một từ (chuỗi các ký tự độ dài tùy ý) thuộc ngôn ngữ nào trong 5 ngôn ngữ cho trước.
models.py: Xây dựng Mạng nơ-ron hồi quy (RNN). Khai báo 3 lớp trọng số: Wx (cho ký tự hiện tại), Wh (cho trạng thái quá khứ) và Wout (cho đầu ra). Trạng thái h được cập nhật liên tục khi quét qua từng ký tự.
losses.py: Cross-Entropy Loss.
train.py: Sử dụng hàm movedim để hoán đổi chiều dữ liệu nhằm lặp qua trục thời gian (từng ký tự) thay vì trục batch. Huấn luyện trong 15 epoch.
5. Question 5 (3/3 điểm): Convolutional Neural Networks (Mạng tích chập)
Mục tiêu: Khai thác cấu trúc không gian 2D của ảnh (thay vì duỗi thẳng ảnh ngay từ đầu như Q3) để giảm lượng tham số cần thiết.
models.py: Hiện thực hàm Convolve thủ công bằng cách trượt bộ lọc (kernel/weight 3x3) khắp bức ảnh. Dữ liệu sau khi tích chập (kích thước 26x26) mới được flatten để đưa vào mạng MLP phân loại.
losses.py: Cross-Entropy Loss.
train.py: Huấn luyện bằng Adam optimizer trong 5 epoch, do CNN đã trích xuất đặc trưng hình ảnh rất tốt nên hội tụ nhanh.
6. Question 6 (2/2 điểm): Scaled Dot-Product Attention (Cơ chế chú ý)
Mục tiêu: Hiện thực cơ chế cốt lõi của kiến trúc Transformer (nền tảng của ChatGPT).
models.py: Tạo 3 lớp Linear tạo ra Q (Query), K (Key), V (Value). Tính toán ma trận Attention bằng công thức: softmaxQKTdkV, đồng thời áp dụng Mask để mô hình không "nhìn trộm" các từ trong tương lai.
train.py & losses.py: Autograder chấm trực tiếp logic toán học của hàm forward, không yêu cầu viết vòng lặp huấn luyện.
7. Question 7 (0 điểm - Optional): Character-GPT
Mục tiêu: Ứng dụng lớp Attention ở Q6 để xây dựng một mô hình ngôn ngữ tự hồi quy (Autoregressive Language Model) quy mô nhỏ, có khả năng dự đoán và sinh ra ký tự tiếp theo trong một câu văn.
Trạng thái: Dự án đã lập trình sẵn để bạn chạy thử nghiệm thực tế (chạy python chargpt.py), giúp bạn hình dung nguyên lý tự sinh văn bản của AI, không thuộc phần chấm điểm của máy.
