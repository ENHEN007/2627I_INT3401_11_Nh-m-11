Mục đích tối thượng của Project 5 là xây dựng sự tiến hóa của mạng nơ-ron nhân tạo từ mức sơ khai nhất đến các kiến trúc Deep Learning hiện đại sử dụng PyTorch. Các câu hỏi từ Q1 đến Q7 tạo thành một chuỗi phát triển có hệ thống: mô hình sau ra đời nhằm khắc phục nhược điểm của mô hình trước để xử lý các loại dữ liệu phức tạp hơn, chuyển từ số liệu vô hướng sang xử lý hình ảnh không gian 2D và cuối cùng là chuỗi văn bản thời gian thực.
Dưới đây là hệ thống hóa vai trò và ý nghĩa thực tiễn của từng phần để bạn gửi cho nhóm:

Phần của Nghĩa: Nền tảng Học máy (Q1, Q2)
Q1 (Perceptron): Xây dựng thuật toán phân loại tuyến tính cơ sở. Thực tế áp dụng cho các bài toán phân loại nhị phân đơn giản (ví dụ: phân loại email spam) bằng cách tự động tinh chỉnh trọng số khi dự đoán sai.
Q2 (Non-linear Regression): Giới thiệu Multi-Layer Perceptron (MLP) với hàm kích hoạt phi tuyến và thuật toán lan truyền ngược. Trong thực tế, mô hình này dùng để dự báo các giá trị liên tục (như giá nhà, chứng khoán) dựa trên nhiều biến số đầu vào.

Phần của Dũng: Thị giác Máy tính (Q3, Q5)
Q3 (Digit Classification): Dùng mạng MLP nhiều lớp để nhận diện ảnh chữ số viết tay. Nhược điểm ở bước này là phải duỗi thẳng ảnh 2D thành vector 1D, làm mất đi các đặc trưng hình học không gian của bức ảnh.
Q5 (Convolutional Neural Network): Giải quyết triệt để nhược điểm của Q3 bằng mạng tích chập. Việc dùng bộ lọc quét qua ảnh giúp trích xuất góc cạnh, hình khối cực kỳ hiệu quả, tạo nền tảng cho các hệ thống nhận diện khuôn mặt thực tế.

Phần của Tuân: Xử lý Ngôn ngữ Tự nhiên (Q4, Q6, Q7)
Q4 (Language Identification): Xây dựng mạng nơ-ron hồi quy (RNN) để xử lý dữ liệu chuỗi có độ dài tùy ý. Mô hình lưu trữ trạng thái ẩn từ quá khứ để phân tích ngữ cảnh, ứng dụng trực tiếp vào việc dịch máy hoặc nhận diện ngôn ngữ.
Q6 (Scaled Dot-Product Attention): Khắc phục điểm yếu "nhớ trước quên sau" của RNN khi xử lý câu dài. Cơ chế Attention tính toán mức độ quan trọng của mọi từ cùng lúc, đóng vai trò là lõi xử lý của các kiến trúc Transformer hiện đại.
Q7 (Character-GPT): Ứng dụng trực tiếp khối Attention ở Q6 để xây dựng mô hình ngôn ngữ tự hồi quy thu nhỏ. Nhiệm vụ này mô phỏng chính xác nguyên lý cốt lõi của các AI tạo sinh như ChatGPT trong việc dự đoán chữ cái tiếp theo.

