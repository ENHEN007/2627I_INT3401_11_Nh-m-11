import re
import unicodedata
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset
from torch.utils.data.dataloader import DataLoader

from gpt_model import Character_GPT


class CharDataset(Dataset):
    def __init__(self, data, block_size=128):
        self.block_size = block_size

        chars = sorted(list(set(data)))
        self.index2char = {i: ch for i, ch in enumerate(chars)}
        self.char2index = {ch: i for i, ch in enumerate(chars)}
        self.vocab_size = len(chars)
        self.data = data

    def __len__(self):
        return len(self.data) - self.block_size

    def __getitem__(self, idx):
        chunk = self.data[idx:idx + self.block_size + 1]
        dix = [self.char2index[s] for s in chunk]
        x = torch.tensor(dix[:-1], dtype=torch.long)
        y = torch.tensor(dix[1:], dtype=torch.long)
        return x, y


# Tập hợp toàn bộ nguyên âm tiếng Việt để kiểm tra âm tiết hợp lệ
NGUYEN_AM_VN = set(
    "aàảãáạăằẳẵắặâầẩẫấậeèẻẽéẹêềểễếệiìỉĩíịoòỏõóọôồổỗốộơờởỡớợuùủũúụưừửữứựyỳỷỹýỵ"
    "AÀẢÃÁẠĂẰẲẴẮẶÂẦẨẪẤẬEÈẺẼÉẸÊỀỂỄẾỆIÌỈĨÍỊOÒỎÕÓỌÔỒỔỖỐỘƠỜỞỠỚỢUÙỦŨÚỤƯỪỬỮỨỰYỲỶỸÝỴ"
)


@torch.no_grad()
def generate_poem(model, idx, max_new_tokens, dataset, temperature=0.5, top_k=5):
    """Sinh thơ kết hợp lọc xác suất Top-K và khóa quy tắc âm tiết tiếng Việt."""
    model.eval()
    block_size = dataset.block_size
    space_or_punct = set(" ,.!?\n")

    for _ in range(max_new_tokens):
        idx_cond = idx if idx.size(1) <= block_size else idx[:, -block_size:]
        out = model(idx_cond)
        logits = out[0] if isinstance(out, tuple) else out
        logits = logits[:, -1, :] / temperature

        # Lấy văn bản hiện tại để kiểm tra từ đang gõ dở
        current_text = "".join([dataset.index2char[int(i)] for i in idx[0]])
        last_word = re.split(r"[\s,\.\?!]+", current_text)[-1]

        # QUY TẮC 1: Nếu từ đang gõ dở mới có phụ âm (VD: "t", "nh", "th") mà chưa có nguyên âm,
        # cấm AI sinh dấu cách hoặc dấu câu (tránh lỗi "t t tài", "lái nh.", "Ban th")
        if len(last_word) > 0 and not any(ch in NGUYEN_AM_VN for ch in last_word):
            for ch in space_or_punct:
                if ch in dataset.char2index:
                    logits[0, dataset.char2index[ch]] = -float("Inf")

        if top_k is not None:
            v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
            logits[logits < v[:, [-1]]] = -float("Inf")

        probs = F.softmax(logits, dim=-1)
        idx_next = torch.multinomial(probs, num_samples=1)
        idx = torch.cat((idx, idx_next), dim=1)

    model.train()
    return idx


if __name__ == '__main__':
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Đang huấn luyện trên thiết bị: {device}")

    block_size = 128
    layer_size = 160
    n_layer = 6
    batch_size = 64
    learning_rate = 8e-4      # Khởi đầu nhanh vừa phải
    num_iterations = 4500     # Điểm rơi hội tụ đẹp nhất (Loss ~ 0.55 - 0.70)
    checkpoint = 1500

    context = "Trăm năm trong cõi người ta,\nChữ tài chữ mệnh khéo là ghét nhau.\n"

    with open('input.txt', 'r', encoding='utf-8') as f:
        text = unicodedata.normalize('NFC', f.read())

    train_dataset = CharDataset(text, block_size=block_size)

    train_loader = DataLoader(
        train_dataset,
        sampler=torch.utils.data.RandomSampler(train_dataset, replacement=True, num_samples=int(1e10)),
        shuffle=False,
        batch_size=batch_size,
        num_workers=0,
    )
    train_iterations = iter(train_loader)

    model = Character_GPT(
        train_dataset.block_size,
        n_embd=layer_size,
        n_layer=n_layer,
        vocab_size=train_dataset.vocab_size
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=0.01)
    # Tự động giảm dần tốc độ học về cuối để mô hình không bị "nhảy chữ"
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_iterations, eta_min=1e-4)

    valid_context = ''.join([ch for ch in context if ch in train_dataset.char2index])
    if not valid_context:
        valid_context = text[:20]

    model.train()
    for i in range(1, num_iterations + 1):
        try:
            x, y = next(train_iterations)
        except StopIteration:
            train_iterations = iter(train_loader)
            x, y = next(train_iterations)

        x, y = x.to(device), y.to(device)
        loss = model.get_loss(x, y)

        model.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        scheduler.step()

        if i % checkpoint == 0 or i == 1:
            print(f"\n--- Iteration: {i}/{num_iterations} | Loss: {loss.item():.4f} ---")
            x_prompt = torch.tensor(
                [[train_dataset.char2index[s] for s in valid_context]],
                dtype=torch.long,
                device=device
            )
            y_gen = generate_poem(
                model,
                x_prompt,
                max_new_tokens=350,
                dataset=train_dataset,
                temperature=0.5,
                top_k=5
            )[0]
            completion = ''.join([train_dataset.index2char[int(idx)] for idx in y_gen])
            print(completion)