@echo off
chcp 65001 >nul
title Nhom 11 - Project 5 (Deep Learning & NLP)

echo ==============================================================
echo        CHƯƠNG TRÌNH KHỞI CHẠY TỰ ĐỘNG PROJECT 5 - NHÓM 11
echo ==============================================================

:: 1. Kiểm tra nếu chưa có môi trường ảo .venv thì tự động tạo và cài thư viện
if not exist ".venv\Scripts\python.exe" (
    echo [1/2] Đang khởi tạo môi trường ảo (.venv) lần đầu tiên...
    python -m venv .venv
    if errorlevel 1 (
        echo [LỖI] Máy chưa cài Python hoặc chưa tích chọn "Add Python to PATH"!
        pause
        exit /b
    )
    echo [2/2] Đang tải và cài đặt PyTorch, NumPy, Matplotlib, Gradio...
    echo       (Quá trình này chỉ diễn ra 1 lần duy nhất ở lần mở đầu tiên)
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
) else (
    echo [OK] Đã nhận diện môi trường .venv sẵn sàng!
)

:MENU
echo.
echo ==============================================================
echo Chọn chức năng bạn muốn chạy:
echo   [1] Chấm điểm tự động toàn bộ dự án (Autograder Q1 -> Q6)
echo   [2] Mở giao diện Web vẽ chuột nhận diện chữ số (Demo Q3/Q5)
echo   [3] Huấn luyện Character-GPT và sáng tác thơ Truyện Kiều (Q7)
echo   [0] Thoát chương trình
echo ==============================================================
set /p choice="Nhập lựa chọn của bạn (0, 1, 2 hoặc 3) rồi nhấn Enter: "

if "%choice%"=="1" (
    echo.
    ".venv\Scripts\python.exe" autograder.py
    pause
    goto MENU
)
if "%choice%"=="2" (
    echo.
    echo Đang khởi động giao diện Web... (Nhấn Ctrl+C nếu muốn dừng)
    ".venv\Scripts\python.exe" demo_canvas.py
    pause
    goto MENU
)
if "%choice%"=="3" (
    echo.
    ".venv\Scripts\python.exe" chargpt.py
    pause
    goto MENU
)
if "%choice%"=="0" exit /b

echo Lựa chọn không hợp lệ, vui lòng nhập lại!
goto MENU