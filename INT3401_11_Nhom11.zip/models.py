from torch import stack, tril
from torch.nn import Module


"""
Functions you should use.
Please avoid importing any other functions or modules.
Your code will not pass if the gradescope autograder detects any changed imports
"""
# import torch
from torch.nn import Parameter, Linear
from torch import tensor, tensordot, ones, matmul, zeros 
from torch.nn.functional import relu, softmax
from torch import movedim

"""
##################
### QUESTION 1 ###
##################
"""


class PerceptronModel(Module):
    def __init__(self, dimensions):
        super(PerceptronModel, self).__init__()
        # Khởi tạo trọng số w là một ma trận 1 x dimensions chứa toàn số 0
        self.w = Parameter(zeros(1, dimensions))

    def get_weights(self):
        return self.w

    def forward(self, x):
        # Tính tích vô hướng giữa đầu vào x và trọng số (tensordot)
        # Vì w có shape (1, dim), ta lấy self.w[0] để dot product trực tiếp với x
        return tensordot(x, self.w[0], dims=1)

    def get_prediction(self, x):
        # Lấy giá trị vô hướng từ kết quả forward. Lớn hơn hoặc bằng 0 -> lớp 1, ngược lại -> lớp -1
        score = self(x)
        return 1 if score.item() >= 0 else -1


class RegressionModel(Module):
    def __init__(self):
        super().__init__()
        # Khởi tạo MLP 3 lớp với kích thước ẩn (hidden size) lần lượt là 128 và 64
        self.layer1 = Linear(1, 128)
        self.layer2 = Linear(128, 64)
        self.layer3 = Linear(64, 1)

    def forward(self, x):
        # Đưa dữ liệu qua các lớp kết hợp với hàm kích hoạt phi tuyến ReLU
        x = relu(self.layer1(x))
        x = relu(self.layer2(x))
        return self.layer3(x)


class DigitClassificationModel(Module):
    def __init__(self):
        super().__init__()
        input_size = 28 * 28
        output_size = 10
        # MNIST classification cần cấu trúc mạng lớn hơn một chút để hội tụ nhanh
        self.layer1 = Linear(input_size, 256)
        self.layer2 = Linear(256, 128)
        self.layer3 = Linear(128, output_size)

    def forward(self, x):
        # Truyền xuôi dữ liệu: Flatten > Lớp 1 (ReLU) > Lớp 2 (ReLU) > Lớp 3 (Logits)
        x = relu(self.layer1(x))
        x = relu(self.layer2(x))
        return self.layer3(x)


class LanguageIDModel(Module):
    def __init__(self):
        self.num_chars = 47
        self.languages = ["English", "Spanish", "Finnish", "Dutch", "Polish"]
        super(LanguageIDModel, self).__init__()
        
        # Mạng RNN cần 3 khối Linear: xử lý input (Wx), xử lý trạng thái ẩn (Wh) và xuất kết quả (Wout)
        hidden_dim = 256
        self.Wx = Linear(self.num_chars, hidden_dim)
        self.Wh = Linear(hidden_dim, hidden_dim)
        self.Wout = Linear(hidden_dim, 5)

    def forward(self, xs):
        # Trạng thái ẩn h ban đầu có giá trị 0
        batch_size = xs[0].shape[0]
        h = zeros(batch_size, self.Wh.in_features)
        
        # Lặp qua từng ký tự (time step), cập nhật h liên tục
        for x in xs:
            h = relu(self.Wx(x) + self.Wh(h))
            
        return self.Wout(h)


def Convolve(input: tensor, weight: tensor):
    input_tensor_dimensions = input.shape
    weight_dimensions = weight.shape
    
    # Kích thước ảnh sau convolution = Kích thước gốc - Kích thước kernel + 1
    out_y = input_tensor_dimensions[0] - weight_dimensions[0] + 1
    out_x = input_tensor_dimensions[1] - weight_dimensions[1] + 1
    Output_Tensor = zeros((out_y, out_x))
    
    # Trượt bộ lọc (kernel/weight) trên bức ảnh
    for y in range(out_y):
        for x in range(out_x):
            patch = input[y : y + weight_dimensions[0], x : x + weight_dimensions[1]]
            Output_Tensor[y, x] = tensordot(patch, weight, dims=2)

    return Output_Tensor


class DigitConvolutionalModel(Module):
    def __init__(self):
        super().__init__()
        output_size = 10
        self.convolution_weights = Parameter(ones((3, 3)))
        
        # Sau khi tích chập 3x3 trên ảnh 28x28, kích thước giảm xuống 26x26. Khi flatten sẽ thành 26*26 = 676
        self.layer1 = Linear(26 * 26, 128)
        self.layer2 = Linear(128, output_size)

    def forward(self, x):
        x = x.reshape(len(x), 28, 28)
        x = stack(
            list(map(lambda sample: Convolve(sample, self.convolution_weights), x))
        )
        x = x.flatten(start_dim=1)
        
        # Đưa ma trận sau khi Flatten qua mạng Multi-Layer Perceptron
        x = relu(self.layer1(x))
        return self.layer2(x)


class Attention(Module):
    def __init__(self, layer_size, block_size):
        super().__init__()
        self.k_layer = Linear(layer_size, layer_size)
        self.q_layer = Linear(layer_size, layer_size)
        self.v_layer = Linear(layer_size, layer_size)
        self.register_buffer(
            "mask",
            tril(ones(block_size, block_size)).view(1, 1, block_size, block_size),
        )
        self.layer_size = layer_size

    def forward(self, input):
        B, T, C = input.size()

        # Tạo ma trận Q, K, V thông qua các lớp Linear đã định nghĩa
        Q = self.q_layer(input)
        K = self.k_layer(input)
        V = self.v_layer(input)

        # Tính Dot-Product Attention (Q nhân với K chuyển vị)
        # Sử dụng movedim để hoán đổi trục T và C của K tạo thành K^T
        scores = matmul(Q, movedim(K, 1, 2)) / (self.layer_size ** 0.5)

        # Áp dụng cơ chế Masking để che đi các token tương lai
        scores = scores.masked_fill(self.mask[0, 0, :T, :T] == 0, float('-inf'))

        # Chuẩn hóa về phân phối xác suất
        probs = softmax(scores, dim=-1)

        # Trả về kết quả sau khi nhân với V
        return matmul(probs, V)