from torch.nn.functional import mse_loss, cross_entropy

def regression_loss(predictions, labels):
    """
    Tính sai số bình phương trung bình (MSE) cho bài toán hồi quy (Q2).
    """
    return mse_loss(predictions, labels)

def digitclassifier_loss(logits, labels):
    """
    Tính sai số Cross-Entropy cho bài toán phân loại chữ số nhiều lớp (Q3).
    """
    return cross_entropy(logits, labels)

def languageid_loss(logits, labels):
    """
    Tính sai số Cross-Entropy cho bài toán nhận dạng ngôn ngữ (Q4).
    """
    return cross_entropy(logits, labels)

def digitconvolution_Loss(logits, labels):
    """
    Tính sai số Cross-Entropy cho mạng tích chập (Q5).
    """
    return cross_entropy(logits, labels)